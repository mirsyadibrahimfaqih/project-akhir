import 'bootstrap/dist/css/bootstrap.min.css';
import RouterComponent from './Route';

function App() {
  return (
   <RouterComponent />
  );
}

export default App;
