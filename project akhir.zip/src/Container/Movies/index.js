import React from "react";

const MoviesContainer = ()=>{
    return (
        <>
        <h1>Home i m Movies Page</h1>
        </>
    )
}
export default MoviesContainer;