import React from "react";

const ContactContainer = ()=>{
    return (
        <>
        <h1>hello i m Contact Page</h1>
        </>
    )
}
export default ContactContainer