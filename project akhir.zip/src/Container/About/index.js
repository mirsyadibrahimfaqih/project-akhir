import React from "react";

const AboutContainer = ()=>{
    return (
        <>
        <h1>hello i m ABout Page</h1>
        </>
    )
}
export default AboutContainer