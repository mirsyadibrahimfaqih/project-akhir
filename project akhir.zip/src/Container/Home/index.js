import React from "react";

const HomeContainer = ()=>{
    return (
        <>
        <h1>Home i m Home Page</h1>
        </>
    )
}
export default HomeContainer;