import React from "react";

const SearchContainer = ()=>{
    return (
        <>
        <h1>Home i m Search Page</h1>
        </>
    )
}
export default SearchContainer;